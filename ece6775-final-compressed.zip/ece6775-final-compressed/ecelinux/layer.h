//===========================================================================
// layer.h
//===========================================================================
// @brief: This header file defines the interface for the core functions.

#ifndef LAYER_H
#define LAYER_H

typedef bit32_t HLS_SIZE_T;

#include <stdint.h>
#include <hls_math.h>
#include "model.h"
#include "data_short/cos_tab.h"
#include "data_short/sin_tab.h"

//----------------------------------------------------------
// init_1d_mem
//----------------------------------------------------------
template <int C, typename T>
void init_1d_mem (
  T mem[C],
  T val
) {
  INIT_1D_MEM_LOOP_1: for (int i = 0; i < C; i++)
    mem[i] = val;
}

//----------------------------------------------------------
// init_2d_mem
//----------------------------------------------------------
template <int R, int C, typename T>
void init_2d_mem (
  T mem[R][C],
  T val
) {
  INIT_2D_MEM_LOOP_1: for (int i = 0; i < R; i++)
    INIT_2D_MEM_LOOP_2: for (int j = 0; j < C; j++)
      mem[i][j] = val;
}

//----------------------------------------------------------
// init_3d_mem
//----------------------------------------------------------
template <int P, int R, int C, typename T>
void init_3d_mem (
  T mem[P][R][C],
  T val
) {
  INIT_3D_MEM_LOOP_1: for (int i = 0; i < P; i++)
    INIT_3D_MEM_LOOP_2: for (int j = 0; j < R; j++)
      INIT_3D_MEM_LOOP_3: for (int k = 0; k < C; k++)
        mem[i][j][k] = val;
}

//----------------------------------------------------------
// attention_abs
//----------------------------------------------------------
attn_fixed_t attention_abs(attn_fixed_t a) {
  return (a < (attn_fixed_t)0.0) ? (attn_fixed_t)(-a) : a;
}

//----------------------------------------------------------
// attention_sqrt
//----------------------------------------------------------
// fixed64_t attention_sqrt(fixed64_t in) {
//     fixed64_t guess = in / (fixed64_t)2.0; // Initial guess
//     fixed64_t epsilon = 0.0001; // Convergence tolerance

//     ATTENTION_SQRT_LOOP_1: for (int i = 0; i < 10; ++i) {
//       guess = (guess + in / guess) / (fixed64_t)2.0;
//       if (attention_abs(guess * guess - in) < epsilon) break;
//     }

//     return guess;
// }

//----------------------------------------------------------
// rms_norm
//----------------------------------------------------------
template <int C>
void rms_norm(
  attn_fixed_t input[C],
  const float weight[C],
  attn_fixed_t epsilon
) {
  attn_fixed_t variance = 0.0;
  RMS_NORM_LOOP_1: for (int i = 0; i < C; i++){
    variance += input[i] * input[i];
  }

  variance = (attn_fixed_t)1.0 / hls::sqrt(variance / C + epsilon);
  RMS_NORM_LOOP_2: for (int i = 0; i < C; i++)
    input[i] *= variance * (attn_fixed_t)weight[i];
}

//----------------------------------------------------------
// attention_max
//----------------------------------------------------------
template <typename T>
T attention_max(T a, T b) {
  return (a > b) ? a : b;
}

//----------------------------------------------------------
// attention_round
//----------------------------------------------------------
attn_fixed_t attention_round(attn_fixed_t a) {
  return (a > (attn_fixed_t)0.0) ? (attn_fixed_t)(a + (attn_fixed_t)0.5) : (attn_fixed_t)(a - (attn_fixed_t)0.5);
}

//----------------------------------------------------------
// quantize_activation
//----------------------------------------------------------
template <int R, int C>
void quantize_activation(
  attn_fixed_t input[R][C],
  sbit8_t output_states[R][C],
  attn_fixed_t output_scales[R],
  sbit8_t num_bits
) {
  sbit32_t Qn = -(1 << (num_bits - 1));
  sbit32_t Qp = (1 << (num_bits - 1)) - 1;

  QUANTIZE_ACTIVATION_LOOP_1: for (int i = 0; i < R; i++) {
    
      // Calculate the scale for each row
      attn_fixed_t max_val = 0.0;
      QUANTIZE_ACTIVATION_LOOP_2: for (int j = 0; j < C; j++)
          max_val = attention_max<attn_fixed_t>(max_val, attention_abs(input[i][j]));
      attn_fixed_t max_v = attention_max<attn_fixed_t>(max_val, (attn_fixed_t)(1e-5));
      attn_fixed_t scale = (attn_fixed_t)Qp / max_v;
      output_scales[i] = scale;

      // Quantize each element in the row
      QUANTIZE_ACTIVATION_LOOP_3: for (int j = 0; j < C; j++) {
          sbit32_t quantized_value = attention_round(input[i][j] * scale);
          sbit8_t quantized_value_clamped = (quantized_value < Qn) ? Qn : ((quantized_value > Qp) ? Qp : quantized_value);
          output_states[i][j] = (sbit8_t)quantized_value_clamped;
      }
  }
}

//----------------------------------------------------------
// linear_forward_no_mul
//----------------------------------------------------------
template <int R, int IN_C, int OUT_C>
void linear_forward_no_mul (
  sbit8_t input[R][IN_C],
  attn_fixed_t output[R][OUT_C],
  const attn_fixed_t scales[R],
  const uint8_t packed_weights[IN_C/4][OUT_C],
  const attn_fixed_t w_scale
) {
  
  LINEAR_FORWARD_NO_MUL_LOOP_1: for (int i = 0; i < R; i++) {
    LINEAR_FORWARD_NO_MUL_LOOP_2: for (int j = 0; j < OUT_C; j++) {
      LINEAR_FORWARD_NO_MUL_LOOP_3: for (int k = 0; k < IN_C; k+=4) {
        uint8_t packed_val = packed_weights[k/4][j];

        LINEAR_FORWARD_NO_MUL_LOOP_4: for (int l = 0; l < 4 && (k + l) < IN_C; l++) {
          int8_t weight_val = (packed_val >> (2 * l)) & 0b11;
          if (weight_val == 0b01) output[i][j] += input[i][k + l];
          else if (weight_val == 0b10) output[i][j] -= input[i][k + l];
        }
      }
      output[i][j] /= (scales[i] * w_scale);
    }
  }
}

//----------------------------------------------------------
// reshape_2D_to_3D
//----------------------------------------------------------
template <int P, int R, int C>
void reshape_2D_to_3D (
  attn_fixed_t input[P][R*C],
  attn_fixed_t output[R][P][C]
) {
  RESHAPE_2D_TO_3D_LOOP_1: for (int j = 0; j < P; j++)
    RESHAPE_2D_TO_3D_LOOP_2: for (int i = 0; i < R; i++)
      RESHAPE_2D_TO_3D_LOOP_3: for (int k = 0; k < C; k++)
        output[i][j][k] = input[j][i * C + k];
}

//----------------------------------------------------------
// apply_rotary_pos_emb
//----------------------------------------------------------
template <int P, int R, int C>
void apply_rotary_pos_emb (
  attn_fixed_t input_q[R][P][C],
  attn_fixed_t input_k[R][P][C],
  attn_fixed_t output_q[R][P][C],
  attn_fixed_t output_k[R][P][C],
  attn_fixed_t p_id
) {
  
  // half rotate
  attn_fixed_t rotated_q[R][P][C];
  attn_fixed_t rotated_k[R][P][C];
  APPLY_ROTARY_POS_EMB_LOOP_1: for (int i = 0; i < R; i++) {
    APPLY_ROTARY_POS_EMB_LOOP_2: for (int j = 0; j < P; j++) {
      APPLY_ROTARY_POS_EMB_LOOP_3: for (int k = 0; k < C / 2; k++) {
        rotated_q[i][j][k] = - input_q[i][j][k + C / 2];
        rotated_k[i][j][k] = - input_k[i][j][k + C / 2];
        rotated_q[i][j][k + C / 2] = input_q[i][j][k];
        rotated_k[i][j][k + C / 2] = input_k[i][j][k];
      }
    }
  }
  
  // apply rotation
  APPLY_ROTARY_POS_EMB_LOOP_4: for (int i = 0; i < R; i++) {
    APPLY_ROTARY_POS_EMB_LOOP_5: for (int j = 0; j < P; j++) {
      APPLY_ROTARY_POS_EMB_LOOP_6: for (int k = 0; k < C; k++) {
        output_q[i][j][k] = 
          input_q[i][j][k] * (attn_fixed_t)cos_tab[p_id][k] + rotated_q[i][j][k] * (attn_fixed_t)sin_tab[p_id][k];
        output_k[i][j][k] = 
          input_k[i][j][k] * (attn_fixed_t)cos_tab[p_id][k] + rotated_k[i][j][k] * (attn_fixed_t)sin_tab[p_id][k];
      }
    }
  }
}

//----------------------------------------------------------
// cache_update
//----------------------------------------------------------
template <int P, int R, int C>
void cache_update (
  const float cache_in[P][R][C],
  attn_fixed_t cache_out[P][R+1][C],
  attn_fixed_t update[P][1][C]
) {
  CACHE_UPDATE_LOOP_1: for (int i = 0; i < P; i++)
    CACHE_UPDATE_LOOP_2: for (int j = 0; j < R+1; j++)
      CACHE_UPDATE_LOOP_3: for (int k = 0; k < C; k++)
        if (j != R) cache_out[i][j][k] = (attn_fixed_t)cache_in[i][j][k];
        else cache_out[i][j][k] = update[i][0][k];
}

//----------------------------------------------------------
// transpose_last_two_dims
//----------------------------------------------------------
template <int P, int R, int C>
void transpose_last_two_dims (
  attn_fixed_t input[R][P][C],
  attn_fixed_t output[R][C][P]
) {
  TRANSPOSE_LAST_TWO_DIMS_LOOP_1: for (int i = 0; i < R; i++)
    TRANSPOSE_LAST_TWO_DIMS_LOOP_2: for (int j = 0; j < P; j++)
      TRANSPOSE_LAST_TWO_DIMS_LOOP_3: for (int k = 0; k < C; k++)
        output[i][k][j] = input[i][j][k];
}

//----------------------------------------------------------
// GEMM_3D_float
//----------------------------------------------------------
template <
  int P1,
  int R1,
  int C1,
  int P2,
  int R2,
  int C2
> void GEMM_3D_float (
  attn_fixed_t input_1[P1][R1][C1],
  attn_fixed_t input_2[P2][R2][C2],
  attn_fixed_t output[P1][R1][C2]
) {
  GEMM_3D_FLOAT_LOOP_1: for (int i = 0; i < P1; i++) {
    GEMM_3D_FLOAT_LOOP_2: for (int j = 0; j < R1; j++) {
      GEMM_3D_FLOAT_LOOP_3: for (int k = 0; k < C2; k++) {
        output[i][j][k] = 0;
        GEMM_3D_FLOAT_LOOP_4: for (int l = 0; l < C1; l++)
          output[i][j][k] += input_1[i][j][l] * input_2[i][l][k];
      }
    }
  }
}

//----------------------------------------------------------
// create_causal_mask
//----------------------------------------------------------
template <int P>
void create_causal_mask (
  attn_fixed_t mask[P][P]
) {
  CREATE_CAUSAL_MASK_LOOP_1: for (int i = 0; i < P; i++)
    CREATE_CAUSAL_MASK_LOOP_2: for (int j = 0; j < P; j++)
      mask[i][j] = (j <= i) ? (attn_fixed_t)0.0 : FIXED32_MIN;
}

//----------------------------------------------------------
// attention_exp
//----------------------------------------------------------
// attn_fixed_t attention_exp(attn_fixed_t in) {
//     const fixed48_t tolerance = 1e-10;
//     const int MAX_TERMS = 1000;

//     fixed48_t res = 1.0;
//     fixed48_t term = 1.0;

//       ATTENTION_EXP_LOOP_1: for (int n = 1; n <= MAX_TERMS; ++n) {
//         term *= (fixed48_t)in / n;
//         if (attention_abs(term) < tolerance) break;
//         res += term;
//     }

//     return (attn_fixed_t)res;
// }

//----------------------------------------------------------
// softmax
//----------------------------------------------------------
template <int P, int R, int C>
void softmax (
  attn_fixed_t input[R][P][C]
) {
  attn_fixed_t max_val, sum;
  SOFTMAX_LOOP_1: for (int i = 0; i < R; i++) {
    SOFTMAX_LOOP_2: for (int j = 0; j < P; j++) {
      max_val = input[i][j][0];
      SOFTMAX_LOOP_3: for (int k = 1; k < C; k++)
        max_val = attention_max<attn_fixed_t>(max_val, input[i][j][k]);
      sum = 0.0;
      SOFTMAX_LOOP_4: for (int k = 0; k < C; k++) {
        input[i][j][k] = hls::exp(input[i][j][k] - max_val);
        sum += input[i][j][k];
      }
      SOFTMAX_LOOP_5: for (int k = 0; k < C; k++)
        input[i][j][k] /= sum;
    }
  }
}

#endif
